// By Codilo (:

console.clear();

console.log(
"                                                                                   \n" +
"%c                                 @@       %c      @@                               \n" +
"%c                            @@@@@@@@@@    %c   @@@@@@@@@@                          \n" +
"%c                        @@@@@@@@@@@@@@    %c   @@@@@@@@@@@@@@/                     \n" +
"%c                   /@@@@@@@@@@@@@@@@@     %c    @@@@@@@@@@@@@@@@@@                 \n" +
"%c               @@@@@@@@@@@@@@@@@@         %c        @@@@@@@@@@@@@@@@@@             \n" +
"%c           @@@@@@@@@@@@@@@@@@             %c            %@@@@@@@@@@@@@@@@@.        \n" +
"%c         @@@@@@@@@@@@@@@%                 %c                 @@@@@@@@@@@@@@@       \n" +
"%c         @@@@@@@@@@@@@@@(                 %c                 @@@@@@@@@@@@@@@       \n" +
"%c           @@@@@@@@@@@@@@@@@@             %c            #@@@@@@@@@@@@@@@@@*        \n" +
"%c               @@@@@@@@@@@@@@@@@@         %c        @@@@@@@@@@@@@@@@@@             \n" +
"%c    &@@(           *@@@@@@@@@@@@@@@@@/    %c    @@@@@@@@@@@@@@@@@@           &@@&  \n" +
"%c  @@@@@@@@@@            @@@@@@@@@@@@@@@@@@%c@@@@@@@@@@@@@@@@@/           @@@@@@@@@@\n" +
"%c @@@@@@@@@@@@@@@@           @@@@@@@@@@@@@@%c@@@@@@@@@@@@@           ,@@@@@@@@@@@@@@\n" +
"%c @@@@@@@@@@@@@@@@@@@@           &@@@@@@@@@%c@@@@@@@@@           @@@@@@@@@@@@@@@@@@@\n" +
"%c @@@@@@@@@@@@@@@@@@@@@@@@            @@@@@%c@@@@%           @@@@@@@@@@@@@@@@@@@@@@@\n" +
"%c @@@@@@@@@ ,@@@@@@@@@@@@@@@@@@            %c           ,@@@@@@@@@@@@@@@@@& @@@@@@@@\n" +
"%c @@@@@@@@@      @@@@@@@@@@@@@@@@@@        %c       @@@@@@@@@@@@@@@@@@      @@@@@@@@\n" +
"%c @@@@@@@@@          @@@@@@@@@@@@@@@@@@    %c   @@@@@@@@@@@@@@@@@@          @@@@@@@@\n" +
"%c @@@@@@@@@              .@@@@@@@@@@@@@@   %c  @@@@@@@@@@@@@@%              @@@@@@@@\n" +
"%c @@@@@@@@@                   @@@@@@@@@@   %c  @@@@@@@@@@,                  @@@@@@@@\n" +
"%c @@@@@@@@@                    %@@@@@@@@   %c  @@@@@@@@@                    @@@@@@@@\n" +
"%c @@@@@@@@@                    %@@@@@@@@   %c  @@@@@@@@@                    @@@@@@@@\n" +
"%c  @@@@@@@                     %@@@@@@@@   %c  @@@@@@@@@                     @@@@@@(\n" +
"%c                              %@@@@@@@@   %c  @@@@@@@@@                            \n" +
"%c                              %@@@@@@@@   %c  @@@@@@@@@                            \n" +
"%c            @@@@@             %@@@@@@@@   %c  @@@@@@@@@              @@@@          \n" +
"%c          @@@@@@@@@@@         %@@@@@@@@   %c  @@@@@@@@@         @@@@@@@@@@@        \n" +
"%c          @@@@@@@@@@@@@@@*    %@@@@@@@@   %c  @@@@@@@@@     @@@@@@@@@@@@@@@        \n" +
"%c            @@@@@@@@@@@@@@@@@@%@@@@@@@@   %c  @@@@@@@@@ @@@@@@@@@@@@@@@@@&         \n" +
"%c                @@@@@@@@@@@@@@@@@@@@@@@   %c  @@@@@@@@@@@@@@@@@@@@@@@,             \n" +
"%c                    #@@@@@@@@@@@@@@@@@@   %c  @@@@@@@@@@@@@@@@@@@                  \n" +
"%c                        .@@@@@@@@@@@@@@   %c  @@@@@@@@@@@@@@@                      \n" +
"%c                             @@@@@@@@@@   %c  @@@@@@@@@@,                          \n" +
"%c                                                                                   \n" +
"%c                               https://Codilo.ir (:                                \n",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #3949AB;font-weight: bold;",
"color: #D32F2F;font-weight: bold;", "color: #D32F2F;font-weight: bold;");